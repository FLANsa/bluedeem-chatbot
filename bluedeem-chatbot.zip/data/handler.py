"""CSV data handler with validation, normalization, and caching."""
import csv
import json
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import date
from cachetools import TTLCache
import config
from utils.date_parser import get_today_riyadh


# Cache with TTL
cache = TTLCache(maxsize=100, ttl=config.CACHE_TTL)


# Expected CSV schemas
DOCTORS_SCHEMA = [
    'doctor_id', 'doctor_name', 'specialty', 'branch_id', 'days',
    'time_from', 'time_to', 'phone', 'email', 'experience_years',
    'qualifications', 'notes'
]

BRANCHES_SCHEMA = [
    'branch_id', 'branch_name', 'address', 'city', 'phone', 'email',
    'hours_weekdays', 'hours_weekend', 'maps_url', 'features',
    'parking', 'accessibility'
]

SERVICES_SCHEMA = [
    'service_id', 'service_name', 'specialty', 'description', 'price_sar',
    'price_range', 'available_branch_ids', 'duration_minutes',
    'preparation_required', 'popular'
]

AVAILABILITY_SCHEMA = [
    'date', 'doctor_id', 'branch_id', 'available', 'note', 'last_updated'
]


def normalize_bool(value: str) -> bool:
    """Normalize boolean values."""
    if not value:
        return False
    value_lower = value.lower().strip()
    return value_lower in ['نعم', 'yes', 'true', '1', 'y', 'ن']


def normalize_list(value: str) -> List[str]:
    """Normalize comma-separated list."""
    if not value:
        return []
    return [item.strip() for item in value.split(',') if item.strip()]


def validate_schema(rows: List[Dict], expected_schema: List[str], file_name: str) -> bool:
    """Validate CSV schema."""
    if not rows:
        return True
    
    actual_columns = set(rows[0].keys())
    expected_columns = set(expected_schema)
    
    missing = expected_columns - actual_columns
    if missing:
        raise ValueError(f"Missing columns in {file_name}: {missing}")
    
    return True


def read_csv_file(file_path: Path) -> List[Dict[str, str]]:
    """Read CSV file and return as list of dictionaries."""
    if not file_path.exists():
        raise FileNotFoundError(f"CSV file not found: {file_path}")
    
    rows = []
    with open(file_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(row)
    
    return rows


def normalize_doctors_data(rows: List[Dict]) -> List[Dict[str, Any]]:
    """Normalize doctors data."""
    normalized = []
    for row in rows:
        normalized_row = {
            'doctor_id': row.get('doctor_id', '').strip(),
            'doctor_name': row.get('doctor_name', '').strip(),
            'specialty': row.get('specialty', '').strip(),
            'branch_id': row.get('branch_id', '').strip(),
            'days': row.get('days', '').strip(),
            'time_from': row.get('time_from', '').strip(),
            'time_to': row.get('time_to', '').strip(),
            'phone': row.get('phone', '').strip(),
            'email': row.get('email', '').strip(),
            'experience_years': row.get('experience_years', '').strip(),
            'qualifications': row.get('qualifications', '').strip(),
            'notes': row.get('notes', '').strip()
        }
        normalized.append(normalized_row)
    return normalized


def normalize_branches_data(rows: List[Dict]) -> List[Dict[str, Any]]:
    """Normalize branches data."""
    normalized = []
    for row in rows:
        features = normalize_list(row.get('features', ''))
        normalized_row = {
            'branch_id': row.get('branch_id', '').strip(),
            'branch_name': row.get('branch_name', '').strip(),
            'address': row.get('address', '').strip(),
            'city': row.get('city', '').strip(),
            'phone': row.get('phone', '').strip(),
            'email': row.get('email', '').strip(),
            'hours_weekdays': row.get('hours_weekdays', '').strip(),
            'hours_weekend': row.get('hours_weekend', '').strip(),
            'maps_url': row.get('maps_url', '').strip(),
            'features': features,
            'parking': normalize_bool(row.get('parking', '')),
            'accessibility': normalize_bool(row.get('accessibility', ''))
        }
        normalized.append(normalized_row)
    return normalized


def normalize_services_data(rows: List[Dict]) -> List[Dict[str, Any]]:
    """Normalize services data."""
    normalized = []
    for row in rows:
        available_branch_ids = normalize_list(row.get('available_branch_ids', ''))
        normalized_row = {
            'service_id': row.get('service_id', '').strip(),
            'service_name': row.get('service_name', '').strip(),
            'specialty': row.get('specialty', '').strip(),
            'description': row.get('description', '').strip(),
            'price_sar': row.get('price_sar', '').strip(),
            'price_range': row.get('price_range', '').strip(),
            'available_branch_ids': available_branch_ids,
            'duration_minutes': row.get('duration_minutes', '').strip(),
            'preparation_required': normalize_bool(row.get('preparation_required', '')),
            'popular': normalize_bool(row.get('popular', ''))
        }
        normalized.append(normalized_row)
    return normalized


def normalize_availability_data(rows: List[Dict]) -> List[Dict[str, Any]]:
    """Normalize availability data."""
    normalized = []
    for row in rows:
        normalized_row = {
            'date': row.get('date', '').strip(),
            'doctor_id': row.get('doctor_id', '').strip(),
            'branch_id': row.get('branch_id', '').strip(),
            'available': normalize_bool(row.get('available', '')),
            'note': row.get('note', '').strip(),
            'last_updated': row.get('last_updated', '').strip()
        }
        normalized.append(normalized_row)
    return normalized


class DataHandler:
    """Data handler for CSV files with caching."""
    
    def __init__(self):
        """Initialize data handler."""
        self._doctors = None
        self._branches = None
        self._services = None
        self._availability = None
    
    def _load_doctors(self) -> List[Dict[str, Any]]:
        """Load doctors from CSV."""
        cache_key = 'doctors'
        if cache_key in cache:
            return cache[cache_key]
        
        rows = read_csv_file(config.DOCTORS_CSV)
        validate_schema(rows, DOCTORS_SCHEMA, 'doctors')
        normalized = normalize_doctors_data(rows)
        cache[cache_key] = normalized
        return normalized
    
    def _load_branches(self) -> List[Dict[str, Any]]:
        """Load branches from CSV."""
        cache_key = 'branches'
        if cache_key in cache:
            return cache[cache_key]
        
        rows = read_csv_file(config.BRANCHES_CSV)
        validate_schema(rows, BRANCHES_SCHEMA, 'branches')
        normalized = normalize_branches_data(rows)
        cache[cache_key] = normalized
        return normalized
    
    def _load_services(self) -> List[Dict[str, Any]]:
        """Load services from CSV."""
        cache_key = 'services'
        if cache_key in cache:
            return cache[cache_key]
        
        rows = read_csv_file(config.SERVICES_CSV)
        validate_schema(rows, SERVICES_SCHEMA, 'services')
        normalized = normalize_services_data(rows)
        cache[cache_key] = normalized
        return normalized
    
    def _load_availability(self) -> List[Dict[str, Any]]:
        """Load availability from CSV."""
        cache_key = 'availability'
        if cache_key in cache:
            return cache[cache_key]
        
        rows = read_csv_file(config.AVAILABILITY_CSV)
        validate_schema(rows, AVAILABILITY_SCHEMA, 'availability')
        normalized = normalize_availability_data(rows)
        cache[cache_key] = normalized
        return normalized
    
    def get_doctors(self) -> List[Dict[str, Any]]:
        """Get all doctors."""
        if self._doctors is None:
            self._doctors = self._load_doctors()
        return self._doctors
    
    def get_branches(self) -> List[Dict[str, Any]]:
        """Get all branches."""
        if self._branches is None:
            self._branches = self._load_branches()
        return self._branches
    
    def get_services(self) -> List[Dict[str, Any]]:
        """Get all services."""
        if self._services is None:
            self._services = self._load_services()
        return self._services
    
    def get_doctor_availability(self, date_str: str, doctor_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get doctor availability for a specific date.
        
        Args:
            date_str: Date string (YYYY-MM-DD) or relative date
            doctor_id: Optional doctor ID to filter
            
        Returns:
            List of availability records
        """
        if self._availability is None:
            self._availability = self._load_availability()
        
        # Parse date if relative
        from utils.date_parser import parse_relative_date
        parsed_date = parse_relative_date(date_str)
        if parsed_date:
            date_str = parsed_date.strftime('%Y-%m-%d')
        
        # Filter by date and optionally doctor_id
        results = [
            record for record in self._availability
            if record['date'] == date_str
        ]
        
        if doctor_id:
            results = [r for r in results if r['doctor_id'] == doctor_id]
        
        return results
    
    def get_doctor_availability_today(self, doctor_id: str) -> Optional[Dict[str, Any]]:
        """
        Get doctor availability for today (timezone-aware: Asia/Riyadh).
        
        Args:
            doctor_id: Doctor ID
            
        Returns:
            Availability record or None if not found
        """
        today = get_today_riyadh()
        date_str = today.strftime('%Y-%m-%d')
        
        availability = self.get_doctor_availability(date_str, doctor_id)
        if availability:
            return availability[0]
        return None
    
    def find_doctor_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Find doctor by name (fuzzy matching)."""
        from rapidfuzz import process
        
        doctors = self.get_doctors()
        if not doctors:
            return None
        
        doctor_names = {d['doctor_name']: d for d in doctors}
        result = process.extractOne(name, doctor_names.keys(), score_cutoff=70)
        
        if result:
            return doctor_names[result[0]]
        return None
    
    def find_service_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Find service by name (fuzzy matching)."""
        from rapidfuzz import process
        
        services = self.get_services()
        if not services:
            return None
        
        service_names = {s['service_name']: s for s in services}
        result = process.extractOne(name, service_names.keys(), score_cutoff=70)
        
        if result:
            return service_names[result[0]]
        return None
    
    def get_branch_by_id(self, branch_id: str) -> Optional[Dict[str, Any]]:
        """Get branch by ID."""
        branches = self.get_branches()
        for branch in branches:
            if branch['branch_id'] == branch_id:
                return branch
        return None


# Global instance
data_handler = DataHandler()

