"""Data source abstraction."""
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional


class DataSource(ABC):
    """Abstract base class for data sources."""
    
    @abstractmethod
    def get_doctors(self) -> List[Dict[str, Any]]:
        """Get all doctors."""
        pass
    
    @abstractmethod
    def get_branches(self) -> List[Dict[str, Any]]:
        """Get all branches."""
        pass
    
    @abstractmethod
    def get_services(self) -> List[Dict[str, Any]]:
        """Get all services."""
        pass
    
    @abstractmethod
    def get_doctor_availability(self, date: str, doctor_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get doctor availability for a date."""
        pass


class CSVDataSource(DataSource):
    """CSV data source implementation."""
    
    def __init__(self, handler):
        """Initialize with data handler."""
        self.handler = handler
    
    def get_doctors(self) -> List[Dict[str, Any]]:
        """Get all doctors."""
        return self.handler.get_doctors()
    
    def get_branches(self) -> List[Dict[str, Any]]:
        """Get all branches."""
        return self.handler.get_branches()
    
    def get_services(self) -> List[Dict[str, Any]]:
        """Get all services."""
        return self.handler.get_services()
    
    def get_doctor_availability(self, date: str, doctor_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get doctor availability for a date."""
        return self.handler.get_doctor_availability(date, doctor_id)


class GoogleAppsScriptSource(DataSource):
    """Google Apps Script data source (stub for future implementation)."""
    
    def __init__(self, url: str):
        """Initialize with Google Apps Script URL."""
        self.url = url
        # TODO: Implement Google Apps Script integration
    
    def get_doctors(self) -> List[Dict[str, Any]]:
        """Get all doctors from Google Apps Script."""
        # TODO: Implement
        return []
    
    def get_branches(self) -> List[Dict[str, Any]]:
        """Get all branches from Google Apps Script."""
        # TODO: Implement
        return []
    
    def get_services(self) -> List[Dict[str, Any]]:
        """Get all services from Google Apps Script."""
        # TODO: Implement
        return []
    
    def get_doctor_availability(self, date: str, doctor_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get doctor availability from Google Apps Script."""
        # TODO: Implement
        return []

