"""Database initialization and utilities."""
from models.booking import init_db, SessionLocal
import config


def initialize_database():
    """Initialize database tables."""
    init_db()


def get_database_session():
    """Get database session."""
    return SessionLocal()

