"""Intent classification using GPT-4.1-nano with Structured Outputs."""
from typing import Dict, Any, List
from openai import OpenAI
import config
from models.schemas import IntentSchema, Entity


class IntentClassifier:
    """Intent classifier using GPT-4.1-nano."""
    
    def __init__(self):
        """Initialize intent classifier."""
        if not config.OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY environment variable is required")
        self.client = OpenAI(api_key=config.OPENAI_API_KEY)
        self.model = config.LLM_MODEL_INTENT
    
    def classify(self, message: str, context: Dict[str, Any] = None) -> IntentSchema:
        """
        Classify intent and extract entities.
        
        Args:
            message: User message
            context: Optional context (previous messages, etc.)
            
        Returns:
            IntentSchema with intent, entities, confidence, next_action
        """
        system_prompt = """أنت مصنف نوايا لشات بوت عيادة. صنّف الرسالة وحدد الكيانات.

النوايا المتاحة:
- greeting: تحية
- doctor: سؤال عن طبيب
- branch: سؤال عن فرع
- service: سؤال عن خدمة
- booking: طلب حجز
- hours: سؤال عن الدوام
- contact: طلب التواصل
- faq: سؤال متكرر
- thanks: شكر
- goodbye: وداع
- unclear: غير واضح
- general: عام

الكيانات:
- doctor_name: اسم الطبيب
- service_name: اسم الخدمة
- branch_id: معرف الفرع
- phone: رقم الجوال
- date: تاريخ
- time: وقت

next_action:
- respond_directly: رد مباشر من البيانات
- ask_clarification: اسأل سؤال توضيحي
- use_llm: استخدم LLM للرد
- start_booking: ابدأ عملية الحجز"""
        
        try:
            response = self.client.beta.chat.completions.parse(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": message}
                ],
                response_format=IntentSchema
            )
            
            result = response.choices[0].message.parsed
            if result:
                return result
            # Fallback if parsing fails
            return self._fallback_classify(message)
            
        except Exception as e:
            # Fallback to simple rule-based classification
            return self._fallback_classify(message)
    
    def _fallback_classify(self, message: str) -> IntentSchema:
        """Fallback rule-based classification."""
        message_lower = message.lower()
        
        # Simple keyword matching
        if any(word in message_lower for word in ['مرحبا', 'أهلا', 'السلام', 'هاي']):
            intent = "greeting"
            next_action = "respond_directly"
        elif any(word in message_lower for word in ['طبيب', 'دكتور', 'دكتورة']):
            intent = "doctor"
            next_action = "respond_directly"
        elif any(word in message_lower for word in ['فرع', 'عنوان', 'مكان']):
            intent = "branch"
            next_action = "respond_directly"
        elif any(word in message_lower for word in ['خدمة', 'سعر', 'تكلفة', 'كم']):
            intent = "service"
            next_action = "respond_directly"
        elif any(word in message_lower for word in ['حجز', 'احجز', 'موعد']):
            intent = "booking"
            next_action = "start_booking"
        elif any(word in message_lower for word in ['دوام', 'ساعات', 'متى']):
            intent = "hours"
            next_action = "respond_directly"
        elif any(word in message_lower for word in ['شكر', 'مشكور', 'يعطيك']):
            intent = "thanks"
            next_action = "respond_directly"
        elif any(word in message_lower for word in ['مع السلامة', 'باي', 'وداع']):
            intent = "goodbye"
            next_action = "respond_directly"
        else:
            intent = "unclear"
            next_action = "ask_clarification"
        
        # Simple entity extraction
        entities = []
        # Try to extract doctor name, service name, etc. (simplified)
        
        return IntentSchema(
            intent=intent,
            entities=entities,
            confidence=0.7,
            next_action=next_action
        )

