"""Router layer: intent → data lookup → formatter/LLM decision."""
from typing import Dict, Any, Optional, Tuple, List
from core.intent import IntentClassifier
from core.agent import ChatAgent
from core.formatter import (
    format_doctor_info, format_branch_info, format_service_info,
    format_error_message, format_greeting, format_list
)
from core.booking import BookingManager
from data.handler import data_handler
from utils.date_parser import parse_relative_date


class Router:
    """Router that decides whether to use formatter or LLM."""
    
    def __init__(self):
        """Initialize router."""
        self.intent_classifier = IntentClassifier()
        self.agent = ChatAgent()
        self.booking_manager = BookingManager()
    
    def process(
        self,
        user_id: str,
        platform: str,
        message: str,
        context: Dict[str, Any] = None
    ) -> str:
        """
        Process message and return response.
        
        Args:
            user_id: User ID
            platform: Platform name
            message: User message
            context: Optional context
            
        Returns:
            Response text
        """
        # Check if user is in booking flow
        booking_state = self.booking_manager.get_state(user_id, platform)
        if booking_state:
            response, is_complete = self.booking_manager.process_message(
                user_id, platform, message
            )
            return response
        
        # Classify intent
        intent_result = self.intent_classifier.classify(message, context)
        intent = intent_result.intent
        entities = [e.dict() for e in intent_result.entities]
        next_action = intent_result.next_action
        
        # Handle booking intent
        if intent == "booking" or next_action == "start_booking":
            response, _ = self.booking_manager.process_message(user_id, platform, message)
            return response
        
        # Route based on intent and data availability
        if next_action == "respond_directly":
            return self._respond_directly(intent, entities)
        elif next_action == "ask_clarification":
            return self._ask_clarification(intent, entities)
        else:  # use_llm
            return self._use_llm(message, intent, entities, context)
    
    def _respond_directly(self, intent: str, entities: List[Dict[str, Any]]) -> str:
        """Respond directly using formatter (70-90% of cases)."""
        # Extract entities
        doctor_name = None
        service_name = None
        branch_id = None
        date_str = None
        
        for entity in entities:
            entity_type = entity.get('type', '')
            entity_value = entity.get('value', '')
            
            if entity_type == 'doctor_name':
                doctor_name = entity_value
            elif entity_type == 'service_name':
                service_name = entity_value
            elif entity_type == 'branch_id':
                branch_id = entity_value
            elif entity_type == 'date':
                date_str = entity_value
        
        # Handle different intents
        if intent == "greeting":
            return format_greeting()
        
        elif intent == "doctor":
            if doctor_name:
                doctor = data_handler.find_doctor_by_name(doctor_name)
                if doctor:
                    availability = None
                    if date_str:
                        parsed_date = parse_relative_date(date_str)
                        if parsed_date:
                            availability = data_handler.get_doctor_availability_today(
                                doctor.get('doctor_id')
                            )
                    return format_doctor_info(doctor, availability)
                else:
                    return "⚠️ ما لقيت الطبيب. جرب اسم ثاني."
            else:
                # List all doctors
                doctors = data_handler.get_doctors()
                doctor_names = [d.get('doctor_name', '') for d in doctors]
                return format_list(doctor_names, "الأطباء المتاحون:")
        
        elif intent == "branch":
            if branch_id:
                branch = data_handler.get_branch_by_id(branch_id)
                if branch:
                    return format_branch_info(branch)
                else:
                    return "⚠️ ما لقيت الفرع."
            else:
                # List all branches
                branches = data_handler.get_branches()
                branch_names = [b.get('branch_name', '') for b in branches]
                return format_list(branch_names, "الفروع المتاحة:")
        
        elif intent == "service":
            if service_name:
                service = data_handler.find_service_by_name(service_name)
                if service:
                    branches = data_handler.get_branches()
                    return format_service_info(service, branches)
                else:
                    return "⚠️ ما لقيت الخدمة."
            else:
                # List all services
                services = data_handler.get_services()
                service_names = [s.get('service_name', '') for s in services]
                return format_list(service_names, "الخدمات المتاحة:")
        
        elif intent == "hours":
            branches = data_handler.get_branches()
            if branches:
                response = "⏰ الدوام:\n\n"
                for branch in branches:
                    response += f"{branch.get('branch_name', '')}:\n"
                    if branch.get('hours_weekdays'):
                        response += f"  أيام الأسبوع: {branch.get('hours_weekdays')}\n"
                    if branch.get('hours_weekend'):
                        response += f"  نهاية الأسبوع: {branch.get('hours_weekend')}\n"
                return response.strip()
            return "⏰ ما عندي معلومات عن الدوام حالياً."
        
        elif intent in ["thanks", "goodbye"]:
            return "الله يعطيك العافية! 🌹"
        
        return format_error_message()
    
    def _ask_clarification(self, intent: str, entities: List[Dict[str, Any]]) -> str:
        """Ask clarification question."""
        if intent == "doctor":
            return "❓ أي طبيب تبي تعرف عنه؟"
        elif intent == "service":
            return "❓ أي خدمة تبي تعرف عنها؟"
        elif intent == "branch":
            return "❓ أي فرع تبي تعرف عنه؟"
        else:
            return format_error_message()
    
    def _use_llm(self, message: str, intent: str, entities: List[Dict[str, Any]], context: Dict[str, Any]) -> str:
        """Use LLM for complex responses."""
        agent_response = self.agent.generate_response(message, intent, entities, context)
        return agent_response.response_text

