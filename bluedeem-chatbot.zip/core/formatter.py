"""Response formatter with Najdi dialect templates."""
from typing import Dict, Any, List, Optional


def format_doctor_info(doctor: Dict[str, Any], availability: Optional[Dict[str, Any]] = None) -> str:
    """Format doctor information."""
    name = doctor.get('doctor_name', '')
    specialty = doctor.get('specialty', '')
    branch_id = doctor.get('branch_id', '')
    days = doctor.get('days', '')
    time_from = doctor.get('time_from', '')
    time_to = doctor.get('time_to', '')
    phone = doctor.get('phone', '')
    
    response = f"✅ الدكتور {name}\n"
    if specialty:
        response += f"التخصص: {specialty}\n"
    
    if availability:
        if availability.get('available'):
            response += "📍 موجود اليوم\n"
        else:
            response += "⚠️ مو موجود اليوم\n"
        if availability.get('note'):
            response += f"ملاحظة: {availability['note']}\n"
    else:
        if days:
            response += f"⏰ الدوام: {days}\n"
        if time_from and time_to:
            response += f"⏰ الوقت: {time_from} - {time_to}\n"
    
    if branch_id:
        response += f"📍 الفرع: {branch_id}\n"
    if phone:
        response += f"📞 {phone}\n"
    
    return response.strip()


def format_branch_info(branch: Dict[str, Any]) -> str:
    """Format branch information."""
    name = branch.get('branch_name', '')
    address = branch.get('address', '')
    city = branch.get('city', '')
    phone = branch.get('phone', '')
    hours_weekdays = branch.get('hours_weekdays', '')
    hours_weekend = branch.get('hours_weekend', '')
    maps_url = branch.get('maps_url', '')
    features = branch.get('features', [])
    
    response = f"📍 {name}\n"
    if address:
        response += f"العنوان: {address}"
        if city:
            response += f", {city}"
        response += "\n"
    
    if hours_weekdays:
        response += f"⏰ الدوام (أيام الأسبوع): {hours_weekdays}\n"
    if hours_weekend:
        response += f"⏰ الدوام (عطلة نهاية الأسبوع): {hours_weekend}\n"
    
    if phone:
        response += f"📞 {phone}\n"
    
    if maps_url:
        response += f"🗺️ {maps_url}\n"
    
    if features:
        response += f"⭐ المميزات: {', '.join(features)}\n"
    
    return response.strip()


def format_service_info(service: Dict[str, Any], branches: Optional[List[Dict[str, Any]]] = None) -> str:
    """Format service information."""
    name = service.get('service_name', '')
    description = service.get('description', '')
    price_sar = service.get('price_sar', '')
    price_range = service.get('price_range', '')
    duration = service.get('duration_minutes', '')
    preparation = service.get('preparation_required', False)
    available_branches = service.get('available_branch_ids', [])
    
    response = f"💰 {name}\n"
    if description:
        response += f"{description}\n"
    
    if price_sar:
        response += f"💰 السعر: {price_sar} ريال\n"
    elif price_range:
        response += f"💰 السعر: {price_range}\n"
    
    if duration:
        response += f"⏰ المدة: {duration} دقيقة\n"
    
    if preparation:
        response += "⚠️ يحتاج تحضيرات\n"
    
    if available_branches and branches:
        branch_names = []
        for branch_id in available_branches:
            for branch in branches:
                if branch.get('branch_id') == branch_id:
                    branch_names.append(branch.get('branch_name', branch_id))
                    break
        if branch_names:
            response += f"📍 الفروع المتاحة: {', '.join(branch_names)}\n"
    
    return response.strip()


def format_error_message() -> str:
    """Format error message."""
    return "⚠️ عذراً، ما قدرت أفهم طلبك.\n\nاختر:\n• أطباء\n• فروع\n• خدمات\n• حجز"


def format_booking_confirmation() -> str:
    """Format booking confirmation message."""
    return "✅ تم استلام طلبك وبنرجع لك نأكد الموعد"


def format_clarification_question(question: str) -> str:
    """Format clarification question."""
    return f"❓ {question}"


def format_greeting() -> str:
    """Format greeting message."""
    return "أهلاً وسهلاً! كيف أقدر أساعدك؟\n\n• أطباء\n• فروع\n• خدمات\n• حجز"


def format_booking_question(state: str, data: Dict[str, Any]) -> str:
    """Format booking question based on state."""
    if state == "name":
        return "ما اسمك؟"
    elif state == "phone":
        return "ما رقم جوالك؟"
    elif state == "service":
        return "أي خدمة تبي تحجز؟"
    elif state == "branch":
        return "أي فرع تفضل؟"
    elif state == "date_time":
        return "متى تبي الموعد؟ (تاريخ ووقت)"
    else:
        return "شكراً لك!"


def format_list(items: List[str], title: str = "") -> str:
    """Format list of items."""
    if not items:
        return "ما لقيت شي"
    
    response = f"{title}\n" if title else ""
    for i, item in enumerate(items, 1):
        response += f"{i}. {item}\n"
    return response.strip()

