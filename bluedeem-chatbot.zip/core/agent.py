"""LLM agent using GPT-4.1-mini with Structured Outputs and Function Calling."""
from typing import Dict, Any, Optional, List
from openai import OpenAI
import config
from models.schemas import AgentResponseSchema
from data.handler import data_handler


class ChatAgent:
    """Chat agent using GPT-4.1-mini."""
    
    def __init__(self):
        """Initialize chat agent."""
        if not config.OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY environment variable is required")
        self.client = OpenAI(api_key=config.OPENAI_API_KEY)
        self.model = config.LLM_MODEL_AGENT
    
    def generate_response(
        self,
        message: str,
        intent: str,
        entities: List[Dict[str, Any]],
        context: Dict[str, Any] = None
    ) -> AgentResponseSchema:
        """
        Generate response using LLM with Structured Outputs.
        
        Args:
            message: User message
            intent: Detected intent
            entities: Extracted entities
            context: Optional context
            
        Returns:
            AgentResponseSchema with response_text, needs_clarification, suggested_questions
        """
        system_prompt = """أنت مساعد ذكي لشات بوت عيادة "بلو ديم".

القواعد المهمة:
1. استخدم اللهجة النجدية 100% (بدون فصحى)
2. كن مختصراً ومباشراً
3. لا تكرر الترحيب
4. لا تخترع معلومات - استخدم فقط البيانات المتوفرة
5. إذا غير واضح: ابدأ بـ "عذراً" + قدم خيارات (أطباء/فروع/خدمات/حجز)
6. استخدم الإيموجي باعتدال: ✅ 📍 ⏰ 💰 ⚠️ ⭐

اللهجة النجدية:
- استخدم "أنا" بدل "أنا"
- استخدم "شلون" بدل "كيف"
- استخدم "وين" بدل "أين"
- استخدم "شلونك" بدل "كيف حالك"
- استخدم "الله يعطيك العافية" بدل "شكراً لك" في بعض السياقات"""
        
        # Prepare context with available data
        context_data = self._prepare_context(intent, entities)
        
        user_prompt = f"""الرسالة: {message}

النية: {intent}
الكيانات: {entities}

البيانات المتوفرة:
{context_data}

رد بلهجة نجدية مختصرة ومباشرة."""
        
        try:
            response = self.client.beta.chat.completions.parse(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                response_format=AgentResponseSchema
            )
            
            result = response.choices[0].message.parsed
            if result:
                return result
            # Fallback if parsing fails
            raise Exception("Failed to parse response")
            
        except Exception as e:
            # Fallback response
            return AgentResponseSchema(
                response_text="عذراً، ما قدرت أفهم طلبك. جرب تسأل عن أطباء أو فروع أو خدمات.",
                needs_clarification=True,
                suggested_questions=["أطباء", "فروع", "خدمات", "حجز"]
            )
    
    def _prepare_context(self, intent: str, entities: List[Dict[str, Any]]) -> str:
        """Prepare context data for the agent."""
        context_parts = []
        
        # Extract entity values
        doctor_name = None
        service_name = None
        branch_id = None
        date_str = None
        
        for entity in entities:
            if entity.get('type') == 'doctor_name':
                doctor_name = entity.get('value')
            elif entity.get('type') == 'service_name':
                service_name = entity.get('value')
            elif entity.get('type') == 'branch_id':
                branch_id = entity.get('value')
            elif entity.get('type') == 'date':
                date_str = entity.get('value')
        
        # Get relevant data
        if intent == "doctor" and doctor_name:
            doctor = data_handler.find_doctor_by_name(doctor_name)
            if doctor:
                availability = None
                if date_str:
                    availability = data_handler.get_doctor_availability(date_str, doctor.get('doctor_id'))
                context_parts.append(f"الطبيب: {doctor}")
                if availability:
                    context_parts.append(f"التوفر: {availability}")
        
        elif intent == "service" and service_name:
            service = data_handler.find_service_by_name(service_name)
            if service:
                context_parts.append(f"الخدمة: {service}")
        
        elif intent == "branch" and branch_id:
            branch = data_handler.get_branch_by_id(branch_id)
            if branch:
                context_parts.append(f"الفرع: {branch}")
        
        return "\n".join(context_parts) if context_parts else "لا توجد بيانات محددة"

