"""FastAPI application entry point."""
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import pytz
import config
from routes import webhook, health
from data.db import initialize_database

# Initialize FastAPI app
app = FastAPI(
    title="BlueDeem Chatbot",
    description="Multi-platform chatbot for BlueDeem clinic",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize database
initialize_database()

# Set timezone
RIYADH_TZ = pytz.timezone(config.TIMEZONE)


# Error handlers
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler."""
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error", "detail": str(exc)}
    )


# Include routers
app.include_router(health.router, tags=["health"])
app.include_router(webhook.router, tags=["webhooks"])


@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "service": "BlueDeem Chatbot",
        "status": "running",
        "version": "1.0.0"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)

